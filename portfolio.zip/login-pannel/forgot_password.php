<?php
session_start();
include 'dbConnect.php';


?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Verification</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
  </head>
  <body>
    <?php
    if(isset($_SESSION['status'])){
      ?>
      <div class="alert alert-success">
        <h5><?= $_SESSION['status'];?></h5>
      </div>
      <?php
      unset($_SESSION['status']);
    }
    ?>
    <div class="container container-wrapper">
        <h2>Forgot Password</h2>
        <form action="reset_code.php"  method="POST" class="login">
            <!-- <div class="error-text">Error</div> -->
            <div class="form-group">
                <label class="form-label">Registered Email</label><br>
                <input type="email" name="email" placeholder="enter your mail " autocomplete="off" required>
                <input type="submit" name="resetLink" value="Submit">
            </div>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
  </body>
</html>