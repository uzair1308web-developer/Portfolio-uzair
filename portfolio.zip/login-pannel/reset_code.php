<?php
session_start();
include 'dbConnect.php';
include 'helper.php';

if(isset($_POST['resetLink'])){
    $email = mysqli_real_escape_string($conn,$_POST['email']);
    $token = md5(rand());
    $query = "SELECT email from user where email='$email' LIMIT 1";
    $result = mysqli_query($conn,$query);

    if(mysqli_num_rows($result) > 0){
        $row = mysqli_fetch_array($result);
        $get_name = $row['username'];
        $get_email = $row['email'];

        $update_token = "UPDATE user SET reset_code='$token' WHERE email='$get_email' LIMIT 1";
        $update_token_run = mysqli_query($conn,$update_token);

        if($update_token_run){
            send_link($get_name,$get_email,$token);
            $_SESSION['status'] = "We sent you a email password link.";
            header("location: forgot_password.php");
            exit(0);
        }else{
            $_SESSION['status'] = "something went wrong";
            header("location: forgot_password.php");
            exit(0);
        }
    }else{
        $_SESSION['status'] = "No Email Found";
        header("location: forgot_password.php");
        exit(0);
    }
}

if(isset($_POST['verify'])){
    $email = mysqli_real_escape_string($conn,$_POST['email']);
    $new_password = mysqli_real_escape_string($conn,$_POST['new_password']);
    $confirm_password = mysqli_real_escape_string($conn,$_POST['confirmPassword']);
    $token = mysqli_real_escape_string($conn,$_POST['password_token']);

    if(!empty($token)){
        if(!empty($token) && !empty($new_password) && !empty($confirm_password)){
            $check_token = "SELECT reset_code FROM user WHERE reset_code='$token' ";
            $run = mysqli_query($conn,$check_token);

            if(mysqli_num_rows($run) > 0){
                if($new_password == $confirm_password){
                    $update_password = "UPDATE user SET password='$new_password' where reset_code='$token'";
                    $update_run = mysqli_query($conn,$update_password);

                    if($update_run){
                        $new_token = md5(rand())."funda";
                        $updateToken = "UPDATE user SET reset_code='$new_token' where reset_code='$token'";
                        $tokenRun = mysqli_query($conn,$updateToken);
                        
                        $_SESSION['status'] = "New Password Successfully Update. !";
                        header("location: login.php");
                        exit(0);
                    }
                    else{
                        $_SESSION['status'] = "Did not update password. Something went wrong. !";
                        header("location: reset_password.php?token=$token&email=$email");
                        exit(0);
                    }
                }else{
                    $_SESSION['status'] = "Password and Confirm password does not match";
                    header("location: reset_password.php?token=$token&email=$email");
                    exit(0);
                }
            }else{
                $_SESSION['status'] = "Invalid Token";
                header("location: reset_password.php?token=$token&email=$email");
                exit(0);
            }
        }
        else{
            $_SESSION['status'] = "All Fields are mandatory";
            header("location: reset_password.php?token=$token&email=$email");
            exit(0);
        }
    }else{
        $_SESSION['status'] = "No token Found";
        header("location: reset_password.php");
        exit(0);
    }
}
?>