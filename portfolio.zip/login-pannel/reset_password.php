<?php
session_start();
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Verification</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
  </head>

  <body>
  <?php
    if(isset($_SESSION['status'])){
      ?>
      <div class="alert alert-success">
        <h5><?= $_SESSION['status'];?></h5>
      </div>
      <?php
      unset($_SESSION['status']);
    }
    ?>
    <div class="container container-wrapper">
        <h2>Reset Password</h2>
        <form action="reset_code.php"  method="POST" class="login login1">
            <input type="hidden" name="password_token" value="<?php if(isset($_GET['token'])){echo $_GET['token'];} ?>">
            <!-- <div class="error-text">Error</div> -->
            <div class="field-input">
                <!-- <label class="form-label">Email ID</label> -->
                <input type="hidden" name="email" value="<?php if(isset($_GET['email'])){echo $_GET['email'];}?>" placeholder="enter your email" autocomplete="off">
            </div>
            <div class="field-input">
                <label class="form-label">New Password</label><br>
                <input type="password" name="new_password" placeholder="enter new password" autocomplete="off">
            </div><br>
            <div class="field-input">
                <label class="form-label">Confirm Password</label><br>
                <input type="password" name="confirmPassword" placeholder="confirm your password" autocomplete="off">
            </div>
            <input type="submit" name="verify" value="Verify" class="btn btn-primary my-2">
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>