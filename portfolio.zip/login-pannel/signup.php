<?php
include 'dbconnect.php';
$showAlert = false;
$showError = false;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];
    $cpassword = $_POST["cpassword"];
    $email = $_POST['email'];
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $showError = "Invalid email format";
    } else {



        // $exist = false;

        //Check whether username exists
        $existSql = "SELECT * FROM `user` WHERE username = '$username' ";
        $result = mysqli_query($conn, $existSql);
        $numExistRows = mysqli_num_rows($result);
        if ($numExistRows > 0) {
            // $exist = true;
            $showError = "Username Already exist";
        } else {
            // $exist = false;
            if (($password == $cpassword)) {
                $hash = password_hash($password, PASSWORD_DEFAULT);

                $random_id = rand(time(), 1000000);
                $otp = "0";
                $sql = "INSERT INTO `user` (`unique_id`,`username`, `email` , `password`,  `date`, `otp` ) VALUES ('$random_id', '$username', '$email' , '$hash', current_timestamp(), '$otp')";
                $result = mysqli_query($conn, $sql);
                if ($result) {
                    $sql1 = mysqli_query($conn, "SELECT * FROM user WHERE email = '$email'");
                    if (mysqli_num_rows($sql1) > 0) {
                        $row = mysqli_fetch_assoc($sql1);
                        $_SESSION['unique_id'] = $row['unique_id'];
                        $_SESSION['email'] = $row['email'];
                        $_SESSION['otp'] = $row['otp'];

                        // if($otp){
                        //     $reciever = $email;
                        //     $subject = "FROM: $username <$email>";
                        //     $body = "Name "." $username \n Email "." $email \n "." $otp";
                        //     $sender = "From : uzairkhan7521@gmail.com";

                        //     if(mail($reciever,$subject,$body,$sender)){
                        //         echo "success";
                        //     }
                        //     else{
                        //         echo "email problem " . mysqli_error($conn);
                        //     }

                        $showAlert = true;
                    }
                }
            } else {
                $showError = "Password do not match";
            }
        }
    }
}

?>
<doctype html>
    <html lang="en">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Bootstrap demo</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
        <link rel="stylesheet" href="style.css">
    </head>

    <body>
        <?php require 'nav.php' ?>
        <?php
        if ($showAlert) {
            echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Success!</strong> Your acount created successfully.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>';
        }
        if ($showError) {
            echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Error!</strong> ' . $showError . '
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>';
        }
        ?>

        <div class="container container-wrapper">
            <h1 class="text-center">Register to our page</h1>
            <form action="/projects/login-pannel/signup.php" method="post" class="form-1">
                <div class="form-group mb-3 ">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" class="form-control" id="username" name="username" required>
                </div>
                <div class="form-group mb-3 ">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email" aria-describedby="emailHelp" required>
                </div>
                <div class="form-group mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
                <div class="form-group mb-3">
                    <label for="cpassword" class="form-label">Confirm Password</label>
                    <input type="password" class="form-control" id="cpassword" name="cpassword" required>
                    <p id="emailHelp">Make sure to type same password.</p>
                </div>
                <button type="submit" class="btn btn-primary">Sign up</button>
            </form>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    </body>
    <script>
        if (window.history.replaceState) {
            window.history.replaceState(null, null, window.location.href);
        }
    </script>

    </html>