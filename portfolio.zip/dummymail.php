<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table>
        <tr>
            <th>Name:$_POST['name']</th>
            <td>$_POST['name']</td>
        </tr>
        <tr>
            <th>Email</th>
            <td>$_POST['email']</td>
        </tr>
        <tr>
            <td>Message</td>
            <td>$_POST['message']</td>
        </tr>
    </table>
</body>
</html>